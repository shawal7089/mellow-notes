package dev.mellow.notes;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.ColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.util.DisplayMetrics;
import android.util.TypedValue;

/** Shared look: current theme, sizes and the glassy panel drawables. */
final class Ui {
    private Ui() {}

    static DisplayMetrics dm;
    static float density = 3f;
    static Palette.Theme t = Palette.named("Dusk", 1f);

    static void init(Context c) {
        dm = c.getResources().getDisplayMetrics();
        density = dm.density;
    }

    static int dp(float v) { return Math.round(v * density); }

    static float sp(float v) { return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, dm); }

    /** Soft translucent panel with a faint accent border. */
    static GradientDrawable panel(float radiusDp) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{t.panelTop(), t.panelBottom()});
        g.setCornerRadius(dp(radiusDp));
        g.setStroke(Math.max(1, dp(1)), t.panelBorder());
        return g;
    }

    /** Solid floating bar (selection / paste). */
    static GradientDrawable bar(float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(t.barFill());
        g.setCornerRadius(dp(radiusDp));
        g.setStroke(Math.max(1, dp(1)), t.panelBorder());
        return g;
    }

    static GradientDrawable solid(int color, float radiusDp, int strokeColor) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        if (strokeColor != 0) g.setStroke(Math.max(1, dp(1)), strokeColor);
        return g;
    }

    /** Accent gradient pill (selected chip, buttons). */
    static GradientDrawable accent(float radiusDp, int alpha) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{Palette.alpha(t.a1, t.ga(alpha)), Palette.alpha(t.a2, t.ga(alpha))});
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    /** Window background: gradient with two soft accent glows. */
    static final class GradientBg extends Drawable {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private Shader base, glow1, glow2;

        @Override protected void onBoundsChange(Rect b) {
            int w = b.width(), h = b.height();
            if (w <= 0 || h <= 0) return;
            int alpha = Math.round((t.dark ? 30 : 26) * t.k);
            float r = Math.max(w, h);
            base = new LinearGradient(0, 0, w, h, t.bg1, t.bg2, Shader.TileMode.CLAMP);
            glow1 = new RadialGradient(w * 0.05f, 0, r * 0.75f, Palette.alpha(t.a1, alpha), Palette.alpha(t.a1, 0), Shader.TileMode.CLAMP);
            glow2 = new RadialGradient(w, h, r * 0.65f, Palette.alpha(t.a2, alpha), Palette.alpha(t.a2, 0), Shader.TileMode.CLAMP);
        }

        @Override public void draw(Canvas c) {
            if (base == null) return;
            Rect b = getBounds();
            p.setShader(base);
            c.drawRect(b, p);
            p.setShader(glow1);
            c.drawRect(b, p);
            p.setShader(glow2);
            c.drawRect(b, p);
            p.setShader(null);
        }

        @Override public void setAlpha(int alpha) { }
        @Override public void setColorFilter(ColorFilter cf) { }
        @Override public int getOpacity() { return PixelFormat.OPAQUE; }
    }
}
