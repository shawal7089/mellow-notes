package dev.mellow.notes;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** File helpers. Pure Java so the risky parts (copy / move / delete) are testable off-device. */
public final class FileOps {
    private FileOps() {}

    public static final int SORT_NAME = 0, SORT_SIZE = 1, SORT_TYPE = 2, SORT_DATE = 3;

    public interface Progress { void add(long bytes); }

    public static final class Result {
        public int ok;
        public final List<String> errors = new ArrayList<>();
        public String summary(String verb) {
            String s = verb + " " + ok + " item" + (ok == 1 ? "" : "s");
            if (!errors.isEmpty()) s += " - " + errors.size() + " failed (" + errors.get(0) + ")";
            return s;
        }
    }

    // ---- file kinds ----------------------------------------------------------------
    private static final Map<String, Integer> EXT = new HashMap<>();
    private static void reg(int kind, String exts) { for (String e : exts.split(" ")) EXT.put(e, kind); }
    static {
        reg(0, "png jpg jpeg gif webp bmp svg ico tif tiff avif heic heif jxl raw dng cr2 nef");
        reg(1, "mp4 mkv webm avi mov wmv flv m4v mpg mpeg 3gp");
        reg(2, "mp3 flac ogg opus wav m4a aac wma mid midi amr");
        reg(3, "zip tar gz xz bz2 zst 7z rar tgz lz4 cab iso img");
        reg(4, "pdf doc docx odt rtf txt md epub djvu tex log");
        reg(5, "xls xlsx ods csv tsv");
        reg(6, "ppt pptx odp key");
        reg(7, "py js jsx ts tsx c h cpp hpp rs go java kt sh bash lua rb php html css json toml yaml yml xml sql qml smali");
        reg(8, "apk apks xapk aab exe msi");
    }

    public static String ext(String name) {
        int i = name.lastIndexOf('.');
        if (i <= 0 || i == name.length() - 1) return "";
        return name.substring(i + 1).toLowerCase(Locale.ROOT);
    }

    public static int kindOf(String name) {
        Integer k = EXT.get(ext(name));
        return k == null ? 9 : k;
    }

    // ---- listing / sorting -----------------------------------------------------------
    public static List<Entry> list(File dir, boolean showDot) throws IOException {
        List<Entry> out = new ArrayList<>();
        try (DirectoryStream<Path> ds = Files.newDirectoryStream(dir.toPath())) {
            for (Path p : ds) {
                String name = p.getFileName().toString();
                if (!showDot && name.startsWith(".")) continue;
                Entry e = entryFor(p.toFile(), name);
                if (e != null) out.add(e);
            }
        }
        return out;
    }

    public static Entry entryFor(File f, String name) {
        try {
            Path p = f.toPath();
            BasicFileAttributes a = Files.readAttributes(p, BasicFileAttributes.class, LinkOption.NOFOLLOW_LINKS);
            boolean dir = a.isDirectory();
            if (a.isSymbolicLink()) dir = Files.isDirectory(p);
            return new Entry(f, name, dir, dir ? 0 : a.size(), a.lastModifiedTime().toMillis());
        } catch (IOException | RuntimeException e) {
            return null;
        }
    }

    public static void sort(List<Entry> list, final int key, final boolean desc) {
        Collections.sort(list, (a, b) -> {
            if (a.dir != b.dir) return a.dir ? -1 : 1;
            int c;
            switch (key) {
                case SORT_SIZE: c = Long.compare(a.size, b.size); break;
                case SORT_TYPE: c = Integer.compare(a.kind, b.kind); break;
                case SORT_DATE: c = Long.compare(a.mtime, b.mtime); break;
                default: c = naturalCompare(a.name, b.name);
            }
            if (desc) c = -c;
            if (c == 0) c = naturalCompare(a.name, b.name);
            return c;
        });
    }

    /** Case-insensitive compare where digit runs compare as numbers (photo2 < photo10). */
    public static int naturalCompare(String a, String b) {
        int i = 0, j = 0, n = a.length(), m = b.length();
        while (i < n && j < m) {
            char c = a.charAt(i), d = b.charAt(j);
            if (Character.isDigit(c) && Character.isDigit(d)) {
                int si = i, sj = j;
                while (i < n && Character.isDigit(a.charAt(i))) i++;
                while (j < m && Character.isDigit(b.charAt(j))) j++;
                String x = a.substring(si, i).replaceFirst("^0+(?=.)", "");
                String y = b.substring(sj, j).replaceFirst("^0+(?=.)", "");
                if (x.length() != y.length()) return x.length() < y.length() ? -1 : 1;
                int cmp = x.compareTo(y);
                if (cmp != 0) return cmp;
            } else {
                char lc = Character.toLowerCase(c), ld = Character.toLowerCase(d);
                if (lc != ld) return lc < ld ? -1 : 1;
                i++;
                j++;
            }
        }
        if ((n - i) != (m - j)) return (n - i) < (m - j) ? -1 : 1;
        return a.compareTo(b);
    }

    public static String humanSize(long n) {
        if (n < 1024) return n + " B";
        double v = n;
        String[] u = {"KB", "MB", "GB", "TB"};
        int i = -1;
        while (v >= 1024 && i < u.length - 1) { v /= 1024; i++; }
        return String.format(Locale.US, "%.1f %s", v, u[i]);
    }

    // ---- names ---------------------------------------------------------------------------
    /** A path in `folder` for `name` that does not exist yet: "a.txt", "a (copy).txt", "a (copy 2).txt" ... */
    public static File uniquePath(File folder, String name) {
        File dst = new File(folder, name);
        if (!exists(dst)) return dst;
        int dot = name.lastIndexOf('.');
        String stem = dot > 0 ? name.substring(0, dot) : name;
        String ext = dot > 0 ? name.substring(dot) : "";
        for (int n = 1; ; n++) {
            String tag = n == 1 ? " (copy)" : " (copy " + n + ")";
            dst = new File(folder, stem + tag + ext);
            if (!exists(dst)) return dst;
        }
    }

    public static boolean exists(File f) {
        return Files.exists(f.toPath(), LinkOption.NOFOLLOW_LINKS);
    }

    public static boolean isInside(File child, File parent) {
        String c = canon(child), p = canon(parent);
        return c.equals(p) || c.startsWith(p.endsWith("/") ? p : p + "/");
    }

    private static String canon(File f) {
        try { return f.getCanonicalPath(); } catch (IOException e) { return f.getAbsolutePath(); }
    }

    // ---- copy / move / delete --------------------------------------------------------
    public static void copyRecursive(File src, File dst, Progress p) throws IOException {
        Path sp = src.toPath();
        if (Files.isSymbolicLink(sp)) {
            try { Files.createSymbolicLink(dst.toPath(), Files.readSymbolicLink(sp)); } catch (Exception e) { /* skip links we cannot recreate */ }
            return;
        }
        if (src.isDirectory()) {
            if (!dst.mkdirs() && !dst.isDirectory()) throw new IOException("cannot create " + dst.getName());
            File[] kids = src.listFiles();
            if (kids == null) throw new IOException("cannot read " + src.getName());
            for (File k : kids) copyRecursive(k, new File(dst, k.getName()), p);
            dst.setLastModified(src.lastModified());
        } else {
            try (InputStream in = new FileInputStream(src); OutputStream out = new FileOutputStream(dst)) {
                byte[] buf = new byte[256 * 1024];
                int n;
                while ((n = in.read(buf)) != -1) {
                    out.write(buf, 0, n);
                    if (p != null) p.add(n);
                }
            }
            dst.setLastModified(src.lastModified());
        }
    }

    public static boolean deleteRecursive(File f) {
        boolean ok = true;
        if (f.isDirectory() && !Files.isSymbolicLink(f.toPath())) {
            File[] kids = f.listFiles();
            if (kids != null) for (File k : kids) ok &= deleteRecursive(k);
        }
        return f.delete() && ok;
    }

    /** Moves src into destFolder (rename when possible, otherwise copy then delete). Never overwrites. */
    public static File moveItem(File src, File destFolder, Progress p) throws IOException {
        File dst = uniquePath(destFolder, src.getName());
        if (src.renameTo(dst)) return dst;
        try {
            copyRecursive(src, dst, p);
        } catch (IOException e) {
            deleteRecursive(dst);
            throw e;
        }
        if (!deleteRecursive(src)) throw new IOException("copied, but could not remove the original " + src.getName());
        return dst;
    }

    /** Like moveItem, but to an exact destination path (which must not exist). */
    public static File moveItemAs(File src, File dst) throws IOException {
        if (src.renameTo(dst)) return dst;
        try {
            copyRecursive(src, dst, null);
        } catch (IOException e) {
            deleteRecursive(dst);
            throw e;
        }
        if (!deleteRecursive(src)) throw new IOException("copied, but could not remove the original " + src.getName());
        return dst;
    }

    public static Result paste(List<File> srcs, File dest, boolean cut, Progress p) {
        Result r = new Result();
        for (File src : srcs) {
            String name = src.getName();
            try {
                File parent = src.getParentFile();
                if (cut && parent != null && canon(parent).equals(canon(dest))) continue;
                if (src.isDirectory() && isInside(dest, src)) throw new IOException("cannot put a folder inside itself");
                if (cut) moveItem(src, dest, p);
                else copyRecursive(src, uniquePath(dest, name), p);
                r.ok++;
            } catch (Exception e) {
                r.errors.add(name + ": " + e.getMessage());
            }
        }
        return r;
    }
}
