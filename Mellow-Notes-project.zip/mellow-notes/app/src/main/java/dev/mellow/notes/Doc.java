package dev.mellow.notes;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** A text document as a flat list of blocks (paragraphs, tables, pictures). Pure Java. */
final class Doc {
    String title = "";
    boolean truncated;
    final List<Block> blocks = new ArrayList<>();

    abstract static class Block { }

    static final class Run {
        String text = "";
        boolean b, i, u, s, mono, sup, sub;
        int color;              // 0 = default, otherwise 0xFFRRGGBB
        float size;             // points, 0 = default
        String link;

        Run() { }
        Run(String t) { text = t; }

        Run copyStyle() {
            Run r = new Run();
            r.b = b; r.i = i; r.u = u; r.s = s; r.mono = mono; r.sup = sup; r.sub = sub;
            r.color = color; r.size = size; r.link = link;
            return r;
        }
    }

    static final class Para extends Block {
        final List<Run> runs = new ArrayList<>();
        int heading;            // 0 body, 1..6
        boolean title;
        int level = -1;         // list level, -1 = not a list item
        String bullet = "";
        int align;              // 0 left, 1 centre, 2 right, 3 justify
        float indentPt;
        float hangPt;           // slides: bullet sits this far left of the text
        float spaceBeforePt, spaceAfterPt;
        float lineMult;         // 0 = default
        boolean quote, code;

        String text() {
            StringBuilder sb = new StringBuilder();
            for (Run r : runs) sb.append(r.text);
            return sb.toString();
        }

        boolean isBlank() {
            for (Run r : runs) if (!r.text.trim().isEmpty()) return false;
            return true;
        }
    }

    static final class Pic extends Block {
        File zip;
        String path;
        long wEmu, hEmu;
    }

    static final class Cell {
        final List<Block> blocks = new ArrayList<>();
        int span = 1;
        int bg;
        boolean header;
    }

    static final class Table extends Block {
        final List<List<Cell>> rows = new ArrayList<>();
    }

    static final class Rule extends Block {
        final boolean page;
        Rule(boolean page) { this.page = page; }
    }

    /** Pre-styled text (HTML) that only the Android layer knows how to show. */
    static final class Raw extends Block {
        final Object text;
        Raw(Object t) { text = t; }
    }
}
