package dev.mellow.notes;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.storage.StorageManager;
import android.os.storage.StorageVolume;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsetsController;
import android.view.inputmethod.InputMethodManager;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** The notes library: folders and notes in a soft glass list, with search. */
public class MainActivity extends Activity {
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT, WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    private SharedPreferences prefs;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final List<File> roots = new ArrayList<>();
    private File primary, root, dir;
    private final Set<String> pins = new HashSet<>();
    private boolean sortTitle;

    private FrameLayout rootView;
    private LinearLayout column;
    private TextView titleView, subView, emptyText;
    private EditText searchBox;
    private ListView list;
    private View permView;
    private final List<Object> rows = new ArrayList<>();
    private String query = "";
    private int gen;
    private Adapter adapter;

    @Override protected void onCreate(Bundle b) {
        prefs = getSharedPreferences("mellownotes", MODE_PRIVATE);
        Look.load(this, prefs);
        setTheme(Ui.t.dark ? R.style.AppDark : R.style.AppLight);
        super.onCreate(b);
        sortTitle = prefs.getBoolean("sortTitle", false);
        build();
        if (!hasAccess()) showPermission();
    }

    @Override protected void onResume() {
        super.onResume();
        if (!hasAccess()) return;
        if (permView != null) { rootView.removeView(permView); permView = null; column.setVisibility(View.VISIBLE); }
        if (root == null) start();
        pins.clear();
        pins.addAll(prefs.getStringSet("pins", new HashSet<String>()));
        reload();
    }

    @Override protected void onDestroy() { super.onDestroy(); worker.shutdownNow(); }

    @Override public void onBackPressed() {
        if (searchBox.getVisibility() == View.VISIBLE) { closeSearch(); return; }
        if (dir != null && root != null && !dir.equals(root)) { dir = dir.getParentFile(); reload(); return; }
        super.onBackPressed();
    }

    private boolean hasAccess() { return Environment.isExternalStorageManager(); }

    private void start() {
        roots.clear();
        primary = null;
        StorageManager sm = (StorageManager) getSystemService(Context.STORAGE_SERVICE);
        for (StorageVolume v : sm.getStorageVolumes()) {
            File d = v.getDirectory();
            if (d == null || !Environment.MEDIA_MOUNTED.equals(v.getState())) continue;
            roots.add(d);
            if (v.isPrimary()) primary = d;
        }
        if (primary == null) { primary = Environment.getExternalStorageDirectory(); if (!roots.contains(primary)) roots.add(0, primary); }
        root = Notes.root(primary);
        dir = root;
    }

    // ---- ui -----------------------------------------------------------------------------------------
    private TextView label(String s, float sp, int color, boolean bold) { return Look.label(this, s, sp, color, bold); }

    private IconButton btn(String kind, View.OnClickListener l) {
        IconButton b = new IconButton(this, kind);
        b.setOnClickListener(l);
        return b;
    }

    private void build() {
        final Palette.Theme t = Ui.t;
        rootView = new FrameLayout(this);
        rootView.setBackground(new Ui.GradientBg());
        column = new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);
        column.setPadding(Ui.dp(10), Ui.dp(8), Ui.dp(10), 0);
        rootView.addView(column, new FrameLayout.LayoutParams(MATCH, MATCH));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout tcol = new LinearLayout(this);
        tcol.setOrientation(LinearLayout.VERTICAL);
        tcol.setPadding(Ui.dp(8), 0, 0, 0);
        titleView = label("Notes", 22, t.text, true);
        titleView.setSingleLine(true);
        subView = label("", 12, t.muted, false);
        subView.setSingleLine(true);
        tcol.addView(titleView);
        tcol.addView(subView);
        top.addView(tcol, new LinearLayout.LayoutParams(0, WRAP, 1f));
        top.addView(btn("search", v -> toggleSearch()));
        top.addView(btn("newfolder", v -> newFolder()));
        top.addView(btn("more", v -> menu(v)));
        column.addView(top, new LinearLayout.LayoutParams(MATCH, WRAP));

        searchBox = new EditText(this);
        searchBox.setSingleLine(true);
        searchBox.setHint("Search every note");
        searchBox.setHintTextColor(t.muted);
        searchBox.setTextColor(t.text);
        searchBox.setTextSize(15);
        searchBox.setBackground(Ui.solid(t.field(), 16, t.panelBorder()));
        searchBox.setPadding(Ui.dp(16), Ui.dp(10), Ui.dp(16), Ui.dp(10));
        searchBox.setVisibility(View.GONE);
        searchBox.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable s) { query = s.toString().trim(); reload(); }
        });
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(MATCH, WRAP);
        sp.setMargins(0, Ui.dp(6), 0, Ui.dp(4));
        column.addView(searchBox, sp);

        FrameLayout body = new FrameLayout(this);
        adapter = new Adapter();
        list = new ListView(this);
        list.setAdapter(adapter);
        list.setDivider(null);
        list.setDividerHeight(0);
        list.setSelector(new ColorDrawable(0));
        list.setVerticalScrollBarEnabled(false);
        list.setCacheColorHint(0);
        list.setClipToPadding(false);
        list.setPadding(0, Ui.dp(6), 0, Ui.dp(110));
        list.setOnItemClickListener((p, v, pos, id) -> openRow(rows.get(pos)));
        list.setOnItemLongClickListener((p, v, pos, id) -> { rowMenu(v, rows.get(pos)); return true; });
        body.addView(list, new FrameLayout.LayoutParams(MATCH, MATCH));
        emptyText = label("", 15, t.muted, false);
        emptyText.setGravity(Gravity.CENTER);
        emptyText.setPadding(Ui.dp(30), 0, Ui.dp(30), 0);
        emptyText.setVisibility(View.GONE);
        body.addView(emptyText, new FrameLayout.LayoutParams(MATCH, WRAP, Gravity.CENTER));
        column.addView(body, new LinearLayout.LayoutParams(MATCH, 0, 1f));

        View fab = new View(this) {
            private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            @Override protected void onDraw(Canvas c) {
                float cx = getWidth() / 2f, cy = getHeight() / 2f, r = Math.min(cx, cy) - Ui.dp(2);
                p.setShader(new android.graphics.LinearGradient(0, 0, getWidth(), getHeight(), Ui.t.a1, Ui.t.a2, android.graphics.Shader.TileMode.CLAMP));
                p.setStyle(Paint.Style.FILL);
                c.drawCircle(cx, cy, r, p);
                p.setShader(null);
                Glyphs.draw(c, "plus", cx, cy, Ui.dp(26), 0xFFFFFFFF);
            }
        };
        fab.setElevation(Ui.dp(6));
        fab.setOnClickListener(v -> newNote());
        FrameLayout.LayoutParams fl = new FrameLayout.LayoutParams(Ui.dp(60), Ui.dp(60), Gravity.BOTTOM | Gravity.END);
        fl.setMargins(0, 0, Ui.dp(20), Ui.dp(24));
        rootView.addView(fab, fl);

        setContentView(rootView);
        getWindow().setStatusBarColor(t.bg1);
        getWindow().setNavigationBarColor(t.bg2);
        WindowInsetsController wc = getWindow().getInsetsController();
        if (wc != null) {
            int light = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
            wc.setSystemBarsAppearance(t.dark ? 0 : light, light);
        }
    }

    private void showPermission() {
        column.setVisibility(View.GONE);
        Palette.Theme t = Ui.t;
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(Ui.dp(32), Ui.dp(32), Ui.dp(32), Ui.dp(32));
        View pic = new View(this) {
            @Override protected void onDraw(Canvas c) { Glyphs.draw(c, "edit", getWidth() / 2f, getHeight() / 2f, Ui.dp(84), Ui.t.a1); }
        };
        box.addView(pic, new LinearLayout.LayoutParams(Ui.dp(96), Ui.dp(96)));
        TextView title = label("Allow access to your files", 21, t.text, true);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, Ui.dp(20), 0, Ui.dp(10));
        box.addView(title);
        TextView body = label("Your notes are plain files in Documents/MellowNotes, so any app can open or back them up. "
                + "For that, Android needs “All files access” switched on for Mellow Notes. Tap the button, turn it on and come back.", 15, t.muted, false);
        body.setGravity(Gravity.CENTER);
        box.addView(body);
        TextView b = label("Open settings", 16, Color.WHITE, true);
        b.setBackground(Ui.accent(22, 235));
        b.setPadding(Ui.dp(28), Ui.dp(12), Ui.dp(28), Ui.dp(12));
        b.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + getPackageName())));
            } catch (ActivityNotFoundException e) {
                startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
            }
        });
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(WRAP, WRAP);
        bl.topMargin = Ui.dp(28);
        box.addView(b, bl);
        permView = box;
        rootView.addView(box, 1, new FrameLayout.LayoutParams(MATCH, MATCH));
    }

    private void toggleSearch() {
        if (searchBox.getVisibility() == View.VISIBLE) { closeSearch(); return; }
        searchBox.setVisibility(View.VISIBLE);
        searchBox.requestFocus();
        InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (im != null) im.showSoftInput(searchBox, 0);
    }

    private void closeSearch() {
        searchBox.setText("");
        searchBox.setVisibility(View.GONE);
        query = "";
        InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (im != null) im.hideSoftInputFromWindow(searchBox.getWindowToken(), 0);
        reload();
    }

    private void menu(View anchor) {
        PopupMenu m = new PopupMenu(this, anchor);
        m.getMenu().add(0, 1, 0, sortTitle ? "Sort by date edited" : "Sort by title");
        m.getMenu().add(0, 2, 1, "Appearance");
        m.setOnMenuItemClickListener(it -> {
            if (it.getItemId() == 1) { sortTitle = !sortTitle; prefs.edit().putBoolean("sortTitle", sortTitle).apply(); reload(); }
            else Look.appearanceDialog(this, prefs);
            return true;
        });
        m.show();
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    // ---- data ---------------------------------------------------------------------------------------
    private void reload() {
        if (dir == null) return;
        final int g = ++gen;
        final File d = dir;
        final String q = query;
        final boolean byTitle = sortTitle;
        worker.execute(() -> {
            final List<Object> out = new ArrayList<>();
            if (!q.isEmpty()) {
                out.addAll(Notes.search(root, q, 200));
            } else {
                out.addAll(Notes.foldersIn(d));
                List<Notes.Note> notes = Notes.notesIn(d);
                final Set<String> pn = pins;
                Collections.sort(notes, new Comparator<Notes.Note>() {
                    @Override public int compare(Notes.Note a, Notes.Note b) {
                        boolean pa = pn.contains(a.file.getPath()), pb = pn.contains(b.file.getPath());
                        if (pa != pb) return pa ? -1 : 1;
                        if (byTitle) return a.title.compareToIgnoreCase(b.title);
                        return Long.compare(b.mtime, a.mtime);
                    }
                });
                out.addAll(notes);
            }
            ui.post(() -> {
                if (g != gen) return;
                rows.clear();
                rows.addAll(out);
                adapter.notifyDataSetChanged();
                boolean atRoot = dir.equals(root);
                titleView.setText(!q.isEmpty() ? "Search" : atRoot ? "Notes" : dir.getName());
                int notesCount = 0;
                for (Object o : rows) if (!(o instanceof File)) notesCount++;
                subView.setText(!q.isEmpty() ? notesCount + (notesCount == 1 ? " match" : " matches") : (atRoot ? "" : "Notes / " + relative(dir) + "  ·  ") + notesCount + (notesCount == 1 ? " note" : " notes"));
                if (rows.isEmpty()) {
                    emptyText.setText(!q.isEmpty() ? "Nothing matches “" + q + "”." : "No notes here yet.\nTap + to write one.");
                    emptyText.setVisibility(View.VISIBLE);
                } else emptyText.setVisibility(View.GONE);
            });
        });
    }

    private String relative(File f) {
        String r = root.getPath();
        String p = f.getPath();
        return p.startsWith(r) && p.length() > r.length() ? p.substring(r.length() + 1) : f.getName();
    }

    private void savePins() { prefs.edit().putStringSet("pins", new HashSet<>(pins)).apply(); }

    // ---- actions ------------------------------------------------------------------------------------
    private void newNote() {
        Intent i = new Intent(this, EditorActivity.class);
        i.putExtra("dir", dir.getPath());
        startActivity(i);
    }

    private void openRow(Object o) {
        if (o instanceof File) { dir = (File) o; reload(); return; }
        Notes.Note n = o instanceof Notes.Hit ? ((Notes.Hit) o).note : (Notes.Note) o;
        Intent i = new Intent(this, EditorActivity.class);
        i.putExtra("path", n.file.getPath());
        if (!query.isEmpty()) i.putExtra("find", query);
        startActivity(i);
    }

    private void newFolder() {
        if (dir == null) return;
        final EditText et = new EditText(this);
        et.setSingleLine(true);
        et.setHint("Folder name");
        et.setPadding(Ui.dp(24), Ui.dp(16), Ui.dp(24), Ui.dp(8));
        new AlertDialog.Builder(this).setTitle("New folder").setView(et)
                .setPositiveButton("Create", (d, w) -> {
                    String n = Notes.safeName(et.getText().toString());
                    File f = new File(dir, n);
                    if (f.exists() || !f.mkdirs()) toast("Couldn’t create that folder"); else reload();
                }).setNegativeButton("Cancel", null).show();
    }

    private void rowMenu(View anchor, final Object o) {
        PopupMenu m = new PopupMenu(this, anchor);
        if (o instanceof File) {
            m.getMenu().add(0, 1, 0, "Rename");
            m.getMenu().add(0, 2, 1, "Move to trash");
            m.setOnMenuItemClickListener(it -> {
                final File f = (File) o;
                if (it.getItemId() == 1) renameFolder(f); else trash(f);
                return true;
            });
        } else {
            final Notes.Note n = o instanceof Notes.Hit ? ((Notes.Hit) o).note : (Notes.Note) o;
            boolean pinned = pins.contains(n.file.getPath());
            m.getMenu().add(0, 1, 0, pinned ? "Unpin" : "Pin to top");
            m.getMenu().add(0, 2, 1, "Move to folder…");
            m.getMenu().add(0, 3, 2, "Share");
            m.getMenu().add(0, 4, 3, "Move to trash");
            m.setOnMenuItemClickListener(it -> {
                switch (it.getItemId()) {
                    case 1:
                        if (pins.contains(n.file.getPath())) pins.remove(n.file.getPath()); else pins.add(n.file.getPath());
                        savePins(); reload(); break;
                    case 2: moveDialog(n.file); break;
                    case 3: share(n); break;
                    default: trash(n.file);
                }
                return true;
            });
        }
        m.show();
    }

    private void renameFolder(final File f) {
        final EditText et = new EditText(this);
        et.setSingleLine(true);
        et.setText(f.getName());
        et.setPadding(Ui.dp(24), Ui.dp(16), Ui.dp(24), Ui.dp(8));
        new AlertDialog.Builder(this).setTitle("Rename folder").setView(et)
                .setPositiveButton("Rename", (d, w) -> {
                    File nf = new File(f.getParentFile(), Notes.safeName(et.getText().toString()));
                    if (nf.exists() || !f.renameTo(nf)) toast("Couldn’t rename"); else reload();
                }).setNegativeButton("Cancel", null).show();
    }

    private void trash(final File f) {
        new AlertDialog.Builder(this).setTitle("Move to trash?").setMessage(f.getName())
                .setPositiveButton("Move", (d, w) -> {
                    try {
                        Trash.moveToTrash(f, roots);
                        pins.remove(f.getPath());
                        savePins();
                        reload();
                        toast("Moved to Mellow trash");
                    } catch (Exception e) { toast("Couldn’t move: " + e.getMessage()); }
                }).setNegativeButton("Cancel", null).show();
    }

    private void collect(File d, List<File> out) {
        out.add(d);
        for (File s : Notes.foldersIn(d)) collect(s, out);
    }

    private void moveDialog(final File f) {
        final List<File> all = new ArrayList<>();
        collect(root, all);
        String[] names = new String[all.size()];
        for (int i = 0; i < all.size(); i++) names[i] = all.get(i).equals(root) ? "Notes (top level)" : relative(all.get(i));
        new AlertDialog.Builder(this).setTitle("Move to…").setItems(names, (d, which) -> {
            File target = all.get(which);
            if (target.equals(f.getParentFile())) return;
            String nm = f.getName();
            int dot = nm.lastIndexOf('.');
            File dest = Notes.uniqueFile(target, dot > 0 ? nm.substring(0, dot) : nm, dot > 0 ? nm.substring(dot) : ".md");
            boolean wasPinned = pins.remove(f.getPath());
            if (f.renameTo(dest)) { if (wasPinned) { pins.add(dest.getPath()); savePins(); } reload(); }
            else { if (wasPinned) pins.add(f.getPath()); toast("Couldn’t move it"); }
        }).show();
    }

    private void share(Notes.Note n) {
        try {
            String text = Notes.readAll(n.file, 2 * 1024 * 1024);
            Intent s = new Intent(Intent.ACTION_SEND);
            s.setType("text/plain");
            s.putExtra(Intent.EXTRA_SUBJECT, n.title);
            s.putExtra(Intent.EXTRA_TEXT, text);
            startActivity(Intent.createChooser(s, "Share note"));
        } catch (Exception e) { toast("Couldn’t read the note"); }
    }

    // ---- rows ---------------------------------------------------------------------------------------
    private final class Row extends View {
        private Object item;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();

        Row(Context c) { super(c); }

        void bind(Object o) { item = o; invalidate(); }

        @Override protected void onMeasure(int w, int h) { setMeasuredDimension(MeasureSpec.getSize(w), Ui.dp(item instanceof File ? 62 : 84)); }

        @Override protected void onDraw(Canvas c) {
            if (item == null) return;
            Palette.Theme t = Ui.t;
            float inset = Ui.dp(2), m = Ui.dp(4);
            r.set(inset, m, getWidth() - inset, getHeight() - m);
            GradientCard.draw(c, r, isPressed());
            float x = Ui.dp(16), avail = getWidth() - x - Ui.dp(16);
            p.setStyle(Paint.Style.FILL);
            if (item instanceof File) {
                File f = (File) item;
                Glyphs.draw(c, "folder", x + Ui.dp(12), getHeight() / 2f, Ui.dp(26), t.a1);
                p.setColor(t.text);
                p.setTypeface(Typeface.DEFAULT_BOLD);
                p.setTextSize(Ui.sp(16));
                p.setTextAlign(Paint.Align.LEFT);
                c.drawText(TextUtils.ellipsize(f.getName(), new android.text.TextPaint(p), avail - Ui.dp(80), TextUtils.TruncateAt.END).toString(),
                        x + Ui.dp(36), getHeight() / 2f + Ui.dp(5), p);
                p.setColor(t.muted);
                p.setTypeface(Typeface.DEFAULT);
                p.setTextSize(Ui.sp(13));
                p.setTextAlign(Paint.Align.RIGHT);
                int n = Notes.countIn(f);
                c.drawText(String.valueOf(n), getWidth() - Ui.dp(18), getHeight() / 2f + Ui.dp(5), p);
                return;
            }
            Notes.Note n = item instanceof Notes.Hit ? ((Notes.Hit) item).note : (Notes.Note) item;
            String sub = item instanceof Notes.Hit && !((Notes.Hit) item).snippet.isEmpty() ? ((Notes.Hit) item).snippet : n.preview;
            boolean pinned = pins.contains(n.file.getPath());
            float tw = avail - (pinned ? Ui.dp(26) : 0);
            p.setTextAlign(Paint.Align.LEFT);
            p.setColor(t.text);
            p.setTypeface(Typeface.DEFAULT_BOLD);
            p.setTextSize(Ui.sp(16));
            c.drawText(TextUtils.ellipsize(n.title, new android.text.TextPaint(p), tw, TextUtils.TruncateAt.END).toString(), x, Ui.dp(32), p);
            if (pinned) Glyphs.draw(c, "pin", getWidth() - Ui.dp(26), Ui.dp(27), Ui.dp(16), t.a1);
            p.setColor(t.muted);
            p.setTypeface(Typeface.DEFAULT);
            p.setTextSize(Ui.sp(13.5f));
            String line = sub.isEmpty() ? "No more text" : sub;
            android.text.TextPaint tp = new android.text.TextPaint(p);
            c.drawText(TextUtils.ellipsize(line, tp, avail, TextUtils.TruncateAt.END).toString(), x, Ui.dp(54), p);
            p.setTextSize(Ui.sp(11.5f));
            String meta = ago(n.mtime);
            if (item instanceof Notes.Hit && !dir.equals(n.file.getParentFile()) && n.file.getParentFile() != null) meta = n.file.getParentFile().getName() + "  ·  " + meta;
            c.drawText(meta, x, Ui.dp(72), p);
        }

        @Override public void setPressed(boolean pressed) { super.setPressed(pressed); invalidate(); }
    }

    private static final class GradientCard {
        private static final Paint P = new Paint(Paint.ANTI_ALIAS_FLAG);
        static void draw(Canvas c, RectF r, boolean pressed) {
            Palette.Theme t = Ui.t;
            P.setStyle(Paint.Style.FILL);
            P.setShader(new android.graphics.LinearGradient(r.left, r.top, r.right, r.bottom, t.panelTop(), t.panelBottom(), android.graphics.Shader.TileMode.CLAMP));
            c.drawRoundRect(r, Ui.dp(20), Ui.dp(20), P);
            P.setShader(null);
            if (pressed) { P.setColor(t.hover()); c.drawRoundRect(r, Ui.dp(20), Ui.dp(20), P); }
            P.setStyle(Paint.Style.STROKE);
            P.setStrokeWidth(Math.max(1, Ui.dp(1)));
            P.setColor(t.panelBorder());
            c.drawRoundRect(r, Ui.dp(20), Ui.dp(20), P);
        }
    }

    private static String ago(long tm) {
        long d = System.currentTimeMillis() - tm;
        long min = d / 60000;
        if (min < 1) return "just now";
        if (min < 60) return min + " min ago";
        long h = min / 60;
        if (h < 24) return h + (h == 1 ? " hour ago" : " hours ago");
        long days = h / 24;
        if (days < 30) return days + (days == 1 ? " day ago" : " days ago");
        return DateFormat.getDateInstance(DateFormat.MEDIUM).format(new Date(tm));
    }

    private final class Adapter extends BaseAdapter {
        @Override public int getCount() { return rows.size(); }
        @Override public Object getItem(int i) { return rows.get(i); }
        @Override public long getItemId(int i) { return i; }
        @Override public View getView(int i, View v, ViewGroup parent) {
            Row r = v instanceof Row ? (Row) v : new Row(parent.getContext());
            r.bind(rows.get(i));
            r.requestLayout();
            return r;
        }
    }
}
