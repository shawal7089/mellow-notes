package dev.mellow.notes;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

/** Theme loading and the appearance dialog shared by both screens. */
final class Look {
    private Look() {}

    static void load(Context c, SharedPreferences prefs) {
        Ui.init(c);
        int vibe = Math.max(0, Math.min(2, prefs.getInt("vibe", 1)));
        float k = Palette.VIBE[vibe];
        String name = prefs.getString("palette", "Dusk");
        if ("Custom".equals(name)) Ui.t = Palette.custom(prefs.getInt("customAccent", 0xFF8f9be0), prefs.getBoolean("customDark", true), k);
        else Ui.t = Palette.named(name, k);
    }

    static TextView label(Context c, String s, float sp, int color, boolean bold) {
        TextView tv = new TextView(c);
        tv.setText(s);
        tv.setTextSize(sp);
        tv.setTextColor(color);
        if (bold) tv.setTypeface(Typeface.DEFAULT_BOLD);
        return tv;
    }

    static final class Swatch extends View {
        private int c1, c2;
        private final boolean on;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        Swatch(Context c, int c1, int c2, boolean on) {
            super(c);
            this.c1 = c1;
            this.c2 = c2;
            this.on = on;
        }

        void setColors(int a, int b) { c1 = a; c2 = b; invalidate(); }

        @Override protected void onMeasure(int w, int h) {
            int s = Ui.dp(44);
            setMeasuredDimension(s, s);
        }

        @Override protected void onDraw(Canvas c) {
            float cx = getWidth() / 2f, cy = getHeight() / 2f, r = Ui.dp(15);
            p.setStyle(Paint.Style.FILL);
            p.setShader(new android.graphics.LinearGradient(cx - r, cy - r, cx + r, cy + r, c1, c2, android.graphics.Shader.TileMode.CLAMP));
            c.drawCircle(cx, cy, r, p);
            p.setShader(null);
            if (on) {
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(Ui.dp(2));
                p.setColor(0xFF9A9A9A);
                c.drawCircle(cx, cy, r + Ui.dp(4), p);
            }
        }
    }

    static void appearanceDialog(final Activity a, final SharedPreferences prefs) {
        ScrollView sv = new ScrollView(a);
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(Ui.dp(22), Ui.dp(8), Ui.dp(22), Ui.dp(8));
        sv.addView(box);

        box.addView(sectionLabel(a, "Palette"));
        HorizontalScrollView hs = new HorizontalScrollView(a);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(a);
        String current = prefs.getString("palette", "Dusk");
        for (final String nm : Palette.NAMES) {
            Palette.Theme th = Palette.named(nm, 1f);
            Swatch s = new Swatch(a, th.a1, th.a2, nm.equals(current));
            s.setOnClickListener(v -> {
                prefs.edit().putString("palette", nm).apply();
                a.recreate();
            });
            row.addView(s);
        }
        hs.addView(row);
        box.addView(hs);

        box.addView(sectionLabel(a, "Colour intensity"));
        RadioGroup rg = new RadioGroup(a);
        rg.setOrientation(RadioGroup.HORIZONTAL);
        String[] names = {"Soft", "Balanced", "Vivid"};
        for (int i = 0; i < names.length; i++) {
            RadioButton rb = new RadioButton(a);
            rb.setText(names[i]);
            rb.setId(200 + i);
            rg.addView(rb);
        }
        rg.check(200 + Math.max(0, Math.min(2, prefs.getInt("vibe", 1))));
        rg.setOnCheckedChangeListener((g, id) -> {
            if (prefs.getInt("vibe", 1) != id - 200) {
                prefs.edit().putInt("vibe", id - 200).apply();
                a.recreate();
            }
        });
        box.addView(rg);

        box.addView(sectionLabel(a, "Any colour"));
        float[] hsl = Palette.toHsl(prefs.getInt("customAccent", 0xFF8f9be0));
        final boolean[] dark = {prefs.getBoolean("customDark", true)};
        final Swatch preview = new Swatch(a, 0, 0, false);
        final SeekBar hue = new SeekBar(a);
        hue.setMax(359);
        hue.setProgress(Math.round(hsl[0] * 359f));
        final SeekBar soft = new SeekBar(a);
        soft.setMax(65);
        soft.setProgress(Math.max(0, Math.min(65, Math.round(hsl[1] * 100f) - 25)));
        final CheckBox darkBox = new CheckBox(a);
        darkBox.setText("Dark background");
        darkBox.setChecked(dark[0]);
        final Runnable upd = () -> {
            float h = hue.getProgress() / 359f;
            float s = (soft.getProgress() + 25) / 100f;
            float l = darkBox.isChecked() ? 0.68f : 0.55f;
            preview.setColors(Palette.hsl(h, s, l), Palette.hsl(h + 0.08f, s, l));
        };
        SeekBar.OnSeekBarChangeListener sl = new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar b, int p, boolean u) { upd.run(); }
            @Override public void onStartTrackingTouch(SeekBar b) { }
            @Override public void onStopTrackingTouch(SeekBar b) { }
        };
        hue.setOnSeekBarChangeListener(sl);
        soft.setOnSeekBarChangeListener(sl);
        darkBox.setOnCheckedChangeListener((b, on) -> upd.run());
        upd.run();
        LinearLayout pr = new LinearLayout(a);
        pr.setGravity(Gravity.CENTER_VERTICAL);
        pr.addView(preview);
        TextView hint = label(a, "Hue and softness", 13, Ui.t.muted, false);
        hint.setPadding(Ui.dp(10), 0, 0, 0);
        pr.addView(hint);
        box.addView(pr);
        box.addView(hue);
        box.addView(soft);
        box.addView(darkBox);
        TextView apply = label(a, "Use this colour", 15, Color.WHITE, true);
        apply.setBackground(Ui.accent(20, 235));
        apply.setPadding(Ui.dp(22), Ui.dp(10), Ui.dp(22), Ui.dp(10));
        apply.setOnClickListener(v -> {
            float h = hue.getProgress() / 359f;
            float s = (soft.getProgress() + 25) / 100f;
            float l = darkBox.isChecked() ? 0.68f : 0.55f;
            prefs.edit().putString("palette", "Custom").putInt("customAccent", Palette.hsl(h, s, l))
                    .putBoolean("customDark", darkBox.isChecked()).apply();
            a.recreate();
        });
        LinearLayout.LayoutParams al = new LinearLayout.LayoutParams(-2, -2);
        al.topMargin = Ui.dp(10);
        box.addView(apply, al);

        new AlertDialog.Builder(a).setTitle("Appearance").setView(sv).setPositiveButton("Close", null).show();
    }

    static TextView sectionLabel(Activity a, String s) {
        TextView tv = new TextView(a);
        tv.setText(s);
        tv.setTextSize(13);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setPadding(0, Ui.dp(16), 0, Ui.dp(6));
        return tv;
    }

}
