package dev.mellow.notes;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** Notes are plain .md files in ordinary folders. Pure Java. */
final class Notes {
    private Notes() {}

    static final class Note {
        File file;
        String title = "", preview = "";
        long mtime, size;
    }

    static final class Hit {
        Note note;
        String snippet = "";
    }

    static boolean isNote(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        return !n.startsWith(".") && (n.endsWith(".md") || n.endsWith(".txt") || n.endsWith(".markdown"));
    }

    static File root(File primary) {
        File r = new File(primary, "Documents/MellowNotes");
        if (!r.isDirectory()) r.mkdirs();
        return r;
    }

    static String readAll(File f, int maxBytes) throws IOException {
        try (InputStream in = new FileInputStream(f)) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] b = new byte[16384];
            int n;
            while ((n = in.read(b)) > 0 && bo.size() < maxBytes) bo.write(b, 0, n);
            String s = new String(bo.toByteArray(), StandardCharsets.UTF_8);
            return s.startsWith("﻿") ? s.substring(1) : s;
        }
    }

    static void write(File f, String text) throws IOException {
        File tmp = new File(f.getParentFile(), "." + f.getName() + ".tmp");
        try (FileOutputStream o = new FileOutputStream(tmp)) {
            o.write(text.getBytes(StandardCharsets.UTF_8));
            o.getFD().sync();
        }
        if (!tmp.renameTo(f)) {
            try (FileOutputStream o = new FileOutputStream(f)) { o.write(text.getBytes(StandardCharsets.UTF_8)); }
            tmp.delete();
        }
    }

    static String titleOf(String text) {
        for (String line : text.split("\n", 40)) {
            String t = clean(line);
            if (!t.isEmpty()) return t.length() > 80 ? t.substring(0, 80).trim() : t;
        }
        return "";
    }

    private static String clean(String line) {
        String t = line.trim();
        t = t.replaceAll("^(#{1,6}\\s+|>\\s*|[-*+]\\s+\\[[ xX]\\]\\s*|[-*+]\\s+|\\d+[.)]\\s+)", "");
        t = t.replace("**", "").replace("__", "").replace("`", "");
        return t.trim();
    }

    static String preview(String text) {
        boolean skipped = false;
        StringBuilder sb = new StringBuilder();
        for (String line : text.split("\n", 60)) {
            String t = line.trim();
            if (t.isEmpty()) continue;
            if (!skipped) { skipped = true; continue; }
            if (sb.length() > 0) sb.append("  ");
            sb.append(clean(t));
            if (sb.length() > 160) break;
        }
        return sb.length() > 160 ? sb.substring(0, 160) : sb.toString();
    }

    static Note read(File f) {
        Note n = new Note();
        n.file = f;
        n.mtime = f.lastModified();
        n.size = f.length();
        try {
            String s = readAll(f, 6000);
            n.title = titleOf(s);
            n.preview = preview(s);
        } catch (IOException ignored) { }
        if (n.title.isEmpty()) {
            String nm = f.getName();
            int d = nm.lastIndexOf('.');
            n.title = d > 0 ? nm.substring(0, d) : nm;
        }
        return n;
    }

    static List<Note> notesIn(File dir) {
        List<Note> out = new ArrayList<>();
        File[] fs = dir.listFiles();
        if (fs == null) return out;
        for (File f : fs) if (f.isFile() && isNote(f.getName())) out.add(read(f));
        return out;
    }

    static List<File> foldersIn(File dir) {
        List<File> out = new ArrayList<>();
        File[] fs = dir.listFiles();
        if (fs == null) return out;
        for (File f : fs) if (f.isDirectory() && !f.getName().startsWith(".")) out.add(f);
        Collections.sort(out, new Comparator<File>() {
            @Override public int compare(File a, File b) { return a.getName().compareToIgnoreCase(b.getName()); }
        });
        return out;
    }

    static int countIn(File dir) {
        File[] fs = dir.listFiles();
        int n = 0;
        if (fs != null) for (File f : fs) if (f.isFile() && isNote(f.getName())) n++;
        return n;
    }

    /** Searches names and text of every note under root. */
    static List<Hit> search(File root, String query, int limit) {
        List<Hit> out = new ArrayList<>();
        String q = query.toLowerCase(Locale.ROOT).trim();
        if (q.isEmpty()) return out;
        walk(root, q, out, limit);
        Collections.sort(out, new Comparator<Hit>() {
            @Override public int compare(Hit a, Hit b) { return Long.compare(b.note.mtime, a.note.mtime); }
        });
        return out;
    }

    private static void walk(File dir, String q, List<Hit> out, int limit) {
        File[] fs = dir.listFiles();
        if (fs == null) return;
        for (File f : fs) {
            if (out.size() >= limit) return;
            if (f.isDirectory()) { if (!f.getName().startsWith(".")) walk(f, q, out, limit); continue; }
            if (!isNote(f.getName())) continue;
            try {
                String s = readAll(f, 2 * 1024 * 1024);
                String low = s.toLowerCase(Locale.ROOT);
                int i = low.indexOf(q);
                boolean nameHit = f.getName().toLowerCase(Locale.ROOT).contains(q);
                if (i < 0 && !nameHit) continue;
                Hit h = new Hit();
                h.note = read(f);
                if (i >= 0) {
                    int a = Math.max(0, i - 40), b = Math.min(s.length(), i + q.length() + 80);
                    h.snippet = (a > 0 ? "…" : "") + s.substring(a, b).replace('\n', ' ').trim() + (b < s.length() ? "…" : "");
                }
                out.add(h);
            } catch (IOException ignored) { }
        }
    }

    static String safeName(String title) {
        String t = title.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", " ").replaceAll("\\s+", " ").trim();
        while (t.startsWith(".")) t = t.substring(1).trim();
        if (t.length() > 70) t = t.substring(0, 70).trim();
        return t.isEmpty() ? "Untitled" : t;
    }

    static File uniqueFile(File dir, String base, String ext) {
        File f = new File(dir, base + ext);
        int n = 1;
        while (f.exists()) { n++; f = new File(dir, base + " " + n + ext); }
        return f;
    }

    /** Names the file after the note's first line when it isn't already. Returns the (possibly new) file. */
    static File renameToTitle(File f, String text) {
        String title = safeName(titleOf(text));
        String nm = f.getName();
        int d = nm.lastIndexOf('.');
        String base = d > 0 ? nm.substring(0, d) : nm;
        String ext = d > 0 ? nm.substring(d) : ".md";
        if (base.equals(title) || base.matches(Pattern.quote(title) + " \\d+")) return f;
        File nf = uniqueFile(f.getParentFile(), title, ext);
        return f.renameTo(nf) ? nf : f;
    }

    private static final class Pattern {
        static String quote(String s) { return java.util.regex.Pattern.quote(s); }
    }

    static File newFile(File dir, String text) {
        String t = titleOf(text);
        String base = t.isEmpty() ? "Note " + new java.text.SimpleDateFormat("yyyy-MM-dd HHmm", Locale.US).format(new java.util.Date()) : safeName(t);
        return uniqueFile(dir, base, ".md");
    }
}
