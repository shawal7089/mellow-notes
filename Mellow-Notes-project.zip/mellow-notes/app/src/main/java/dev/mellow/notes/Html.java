package dev.mellow.notes;

import java.io.File;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

/** Turns (X)HTML into Doc blocks. Used for .epub chapters and .html files. Pure Java. */
final class Html {
    private final Doc doc;
    private final File zip;       // for pictures inside an epub, else null
    private final String part;    // path of the page inside the zip
    private Doc.Para cur;
    private int b, i, u, s, code, sup, sub, pre, skip, quote;
    private final Deque<String> links = new ArrayDeque<>();
    private final Deque<int[]> lists = new ArrayDeque<>();   // [ordered, counter]
    private int heading;
    private String pendingBullet = "";
    private Doc.Table table;
    private List<Doc.Cell> row;
    private Doc.Cell cell;
    private final List<Doc.Block> sink;

    private Html(Doc doc, List<Doc.Block> sink, File zip, String part) {
        this.doc = doc;
        this.sink = sink;
        this.zip = zip;
        this.part = part;
    }

    static void convert(Xml x, Doc doc, File zip, String part) {
        x.html = true;
        new Html(doc, doc.blocks, zip, part).run(x);
    }

    private List<Doc.Block> out() { return cell != null ? cell.blocks : sink; }

    private void flush() {
        if (cur == null) return;
        // trim edges
        while (!cur.runs.isEmpty()) {
            Doc.Run last = cur.runs.get(cur.runs.size() - 1);
            if (pre == 0) last.text = stripEnd(last.text);
            if (last.text.isEmpty()) cur.runs.remove(cur.runs.size() - 1); else break;
        }
        if (!cur.runs.isEmpty() && pre == 0) {
            Doc.Run first = cur.runs.get(0);
            first.text = stripStart(first.text);
        }
        if (!cur.runs.isEmpty() && !cur.isBlank() || (pre > 0 && !cur.runs.isEmpty())) {
            if (doc.blocks.size() < 80000) out().add(cur); else doc.truncated = true;
        }
        cur = null;
    }

    private static String stripEnd(String t) {
        int e = t.length();
        while (e > 0 && (t.charAt(e - 1) == ' ' || t.charAt(e - 1) == '\n' || t.charAt(e - 1) == '\t')) e--;
        return t.substring(0, e);
    }

    private static String stripStart(String t) {
        int a = 0;
        while (a < t.length() && (t.charAt(a) == ' ' || t.charAt(a) == '\n' || t.charAt(a) == '\t')) a++;
        return t.substring(a);
    }

    private void startPara() {
        flush();
        cur = new Doc.Para();
        cur.heading = heading;
        if (code > 0 || pre > 0) cur.code = true;
        if (quote > 0) { cur.quote = true; cur.indentPt = 18 * quote; }
        if (!lists.isEmpty()) {
            cur.level = Math.max(0, lists.size() - 1);
            cur.bullet = pendingBullet;
            pendingBullet = "";
        }
    }

    private void text(String t) {
        if (skip > 0 || t.isEmpty()) return;
        if (pre == 0) {
            StringBuilder sb = new StringBuilder(t.length());
            boolean sp = cur != null && !cur.runs.isEmpty() && endsSpace(cur);
            for (int k = 0; k < t.length(); k++) {
                char c = t.charAt(k);
                if (c == ' ' || c == '\n' || c == '\t' || c == '\r') {
                    if (!sp) { sb.append(' '); sp = true; }
                } else {
                    sb.append(c);
                    sp = false;
                }
            }
            t = sb.toString();
            if (t.isEmpty()) return;
            if ((cur == null || cur.runs.isEmpty()) && t.trim().isEmpty()) return;
        }
        if (cur == null) startPara();
        Doc.Run r = new Doc.Run(t);
        r.b = b > 0;
        r.i = i > 0;
        r.u = u > 0;
        r.s = s > 0;
        r.mono = code > 0 || pre > 0;
        r.sup = sup > 0;
        r.sub = sub > 0;
        r.link = links.isEmpty() ? null : links.peek();
        cur.runs.add(r);
    }

    private static boolean endsSpace(Doc.Para p) {
        String t = p.runs.get(p.runs.size() - 1).text;
        return t.endsWith(" ") || t.endsWith("\n");
    }

    private void picture(String src) {
        if (zip == null || src == null || src.startsWith("http") || src.startsWith("data:")) return;
        int q = src.indexOf('#');
        if (q >= 0) src = src.substring(0, q);
        String path = Pkg.resolve(part, java.net.URLDecoder.decode(src.replace("+", "%2B"), java.nio.charset.StandardCharsets.UTF_8));
        Doc.Pic p = new Doc.Pic();
        p.zip = zip;
        p.path = path;
        flush();
        out().add(p);
    }

    private void run(Xml x) {
        while (x.next() != Xml.EOF) {
            if (x.type == Xml.TEXT) { text(x.text); continue; }
            String n = x.name;
            if (x.type == Xml.START) {
                switch (n) {
                    case "head": case "script": case "style": case "title": case "nav": case "svg": case "noscript": case "template":
                        if (n.equals("svg")) {
                            // epub covers are often <svg><image xlink:href=...>: let the image through
                            break;
                        }
                        skip++;
                        break;
                    case "h1": case "h2": case "h3": case "h4": case "h5": case "h6":
                        flush();
                        heading = n.charAt(1) - '0';
                        startPara();
                        break;
                    case "p": case "div": case "section": case "article": case "header": case "footer": case "figure": case "figcaption":
                    case "dd": case "dt": case "address": case "main": case "aside": case "center":
                        if (cell == null || cur != null) startPara();
                        break;
                    case "blockquote": quote++; startPara(); break;
                    case "pre": flush(); pre++; startPara(); break;
                    case "ul": case "ol": flush(); lists.push(new int[]{n.equals("ol") ? 1 : 0, 0}); break;
                    case "li": {
                        int[] l = lists.peek();
                        if (l != null) { l[1]++; pendingBullet = l[0] == 1 ? l[1] + "." : (lists.size() % 3 == 1 ? "•" : lists.size() % 3 == 2 ? "◦" : "▪"); }
                        else pendingBullet = "•";
                        if (lists.isEmpty()) lists.push(new int[]{0, 0});
                        startPara();
                        break;
                    }
                    case "br": if (cur == null) startPara(); text("\n"); break;
                    case "hr": flush(); out().add(new Doc.Rule(false)); break;
                    case "b": case "strong": b++; break;
                    case "i": case "em": case "cite": case "dfn": i++; break;
                    case "u": case "ins": u++; break;
                    case "s": case "strike": case "del": s++; break;
                    case "code": case "tt": case "kbd": case "samp": code++; break;
                    case "sup": sup++; break;
                    case "sub": sub++; break;
                    case "a": links.push(x.attr("href") == null ? "" : x.attr("href")); break;
                    case "img": picture(x.attr("src")); break;
                    case "image": picture(x.attr("href")); break;
                    case "table":
                        flush();
                        table = new Doc.Table();
                        break;
                    case "tr": if (table != null) row = new ArrayList<>(); break;
                    case "td": case "th":
                        if (table != null) {
                            if (row == null) row = new ArrayList<>();
                            cell = new Doc.Cell();
                            cell.header = n.equals("th");
                            cell.span = Math.max(1, x.attrInt("colspan", 1));
                        }
                        break;
                    default: break;
                }
            } else if (x.type == Xml.END) {
                switch (n) {
                    case "head": case "script": case "style": case "title": case "nav": case "noscript": case "template":
                        if (skip > 0) skip--;
                        break;
                    case "h1": case "h2": case "h3": case "h4": case "h5": case "h6": flush(); heading = 0; break;
                    case "p": case "div": case "section": case "article": case "header": case "footer": case "figure": case "figcaption":
                    case "dd": case "dt": case "address": case "main": case "aside": case "center":
                        flush();
                        break;
                    case "blockquote": flush(); if (quote > 0) quote--; break;
                    case "pre": flush(); if (pre > 0) pre--; break;
                    case "ul": case "ol": flush(); if (!lists.isEmpty()) lists.pop(); break;
                    case "li": flush(); break;
                    case "b": case "strong": if (b > 0) b--; break;
                    case "i": case "em": case "cite": case "dfn": if (i > 0) i--; break;
                    case "u": case "ins": if (u > 0) u--; break;
                    case "s": case "strike": case "del": if (s > 0) s--; break;
                    case "code": case "tt": case "kbd": case "samp": if (code > 0) code--; break;
                    case "sup": if (sup > 0) sup--; break;
                    case "sub": if (sub > 0) sub--; break;
                    case "a": if (!links.isEmpty()) links.pop(); break;
                    case "td": case "th":
                        if (cell != null) { flush(); if (row != null) row.add(cell); cell = null; }
                        break;
                    case "tr": if (row != null && table != null) { table.rows.add(row); } row = null; break;
                    case "table":
                        flush();
                        if (table != null) { Doc.Table t = table; table = null; cell = null; if (!t.rows.isEmpty()) out().add(t); }
                        break;
                    default: break;
                }
            }
        }
        flush();
    }
}
