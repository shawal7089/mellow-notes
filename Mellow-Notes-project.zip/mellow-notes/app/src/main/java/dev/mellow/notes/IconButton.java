package dev.mellow.notes;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** Round-cornered icon button drawn with our own glyphs. */
final class IconButton extends View {
    private String kind;
    private boolean on;
    private final Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();

    IconButton(Context c, String kind) {
        super(c);
        this.kind = kind;
        setClickable(true);
        setFocusable(true);
    }

    void setKind(String k) { kind = k; invalidate(); }

    void setOn(boolean b) { on = b; invalidate(); }

    @Override protected void onMeasure(int w, int h) {
        int s = Ui.dp(44);
        setMeasuredDimension(s, s);
    }

    @Override protected void onDraw(Canvas c) {
        Palette.Theme t = Ui.t;
        if (on || isPressed()) {
            bg.setStyle(Paint.Style.FILL);
            bg.setColor(on ? Palette.alpha(t.a1, t.ga(70)) : t.hover());
            r.set(Ui.dp(3), Ui.dp(3), getWidth() - Ui.dp(3), getHeight() - Ui.dp(3));
            c.drawRoundRect(r, Ui.dp(14), Ui.dp(14), bg);
        }
        Glyphs.draw(c, kind, getWidth() / 2f, getHeight() / 2f, Ui.dp(22), t.text);
    }

    @Override public void setPressed(boolean pressed) {
        super.setPressed(pressed);
        invalidate();
    }

    @Override public void setEnabled(boolean enabled) {
        super.setEnabled(enabled);
        setAlpha(enabled ? 1f : 0.35f);
    }
}
