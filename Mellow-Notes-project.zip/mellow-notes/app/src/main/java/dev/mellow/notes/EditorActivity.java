package dev.mellow.notes;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.Selection;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsetsController;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Writes one note. Plain text with a few Markdown helpers, saved as you type. */
public class EditorActivity extends Activity {
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT, WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    private SharedPreferences prefs;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private File file;          // null until there is something to save
    private File dir;
    private EditText edit;
    private DocView read;
    private TextView titleView, subView;
    private IconButton readBtn;
    private boolean reading, loaded;
    private int newlineAt = -1;
    private boolean busy;
    private String lastSaved = "";

    private final Runnable saver = new Runnable() { @Override public void run() { save(); } };

    @Override protected void onCreate(Bundle b) {
        prefs = getSharedPreferences("mellownotes", MODE_PRIVATE);
        Look.load(this, prefs);
        setTheme(Ui.t.dark ? R.style.AppDark : R.style.AppLight);
        super.onCreate(b);
        Paper.set(Ui.t.dark);
        build();
        Intent in = getIntent();
        String path = in.getStringExtra("path");
        String shared = null;
        if (Intent.ACTION_SEND.equals(in.getAction())) {
            String t = in.getStringExtra(Intent.EXTRA_TEXT);
            String sub = in.getStringExtra(Intent.EXTRA_SUBJECT);
            if (t != null) shared = (sub != null && !sub.isEmpty() && !t.startsWith(sub) ? sub + "\n\n" : "") + t;
        }
        if (path != null) {
            file = new File(path);
            dir = file.getParentFile();
            try {
                String s = Notes.readAll(file, 4 * 1024 * 1024);
                busy = true;
                edit.setText(s);
                busy = false;
                lastSaved = s;
            } catch (IOException e) { toast("Couldn’t open this note"); finish(); return; }
            String find = in.getStringExtra("find");
            if (find != null) {
                int i = edit.getText().toString().toLowerCase().indexOf(find.toLowerCase());
                if (i >= 0) edit.setSelection(i, i + find.length());
            }
        } else {
            String d = in.getStringExtra("dir");
            File primary = android.os.Environment.getExternalStorageDirectory();
            dir = d != null ? new File(d) : Notes.root(primary);
            if (!dir.isDirectory()) dir = Notes.root(primary);
            if (shared != null) { busy = true; edit.setText(shared); busy = false; }
        }
        loaded = true;
        updateHeader();
        if (path == null) {
            edit.requestFocus();
            edit.postDelayed(() -> {
                InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (im != null) im.showSoftInput(edit, 0);
            }, 150);
            if (shared != null) schedule();
        }
    }

    @Override protected void onPause() {
        super.onPause();
        ui.removeCallbacks(saver);
        if (loaded) tidy();
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        ui.removeCallbacks(saver);
    }

    @Override public void finish() {
        ui.removeCallbacks(saver);
        if (loaded) tidy();
        super.finish();
    }

    @Override public void onBackPressed() {
        if (reading) { setReading(false); return; }
        super.onBackPressed();
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    // ---- ui -----------------------------------------------------------------------------------------
    private TextView label(String s, float sp, int color, boolean bold) { return Look.label(this, s, sp, color, bold); }

    private IconButton btn(String kind, View.OnClickListener l) {
        IconButton b = new IconButton(this, kind);
        b.setOnClickListener(l);
        return b;
    }

    private void build() {
        final Palette.Theme t = Ui.t;
        FrameLayout root = new FrameLayout(this);
        root.setBackground(new Ui.GradientBg());
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        root.addView(col, new FrameLayout.LayoutParams(MATCH, MATCH));

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackground(Ui.panel(26));
        bar.setPadding(Ui.dp(4), Ui.dp(2), Ui.dp(4), Ui.dp(2));
        bar.addView(btn("back", v -> finish()));
        LinearLayout tcol = new LinearLayout(this);
        tcol.setOrientation(LinearLayout.VERTICAL);
        tcol.setPadding(Ui.dp(4), 0, Ui.dp(4), 0);
        titleView = label("New note", 16, t.text, true);
        titleView.setSingleLine(true);
        titleView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        subView = label("", 11.5f, t.muted, false);
        subView.setSingleLine(true);
        tcol.addView(titleView);
        tcol.addView(subView);
        bar.addView(tcol, new LinearLayout.LayoutParams(0, WRAP, 1f));
        readBtn = btn("show", v -> setReading(!reading));
        bar.addView(readBtn);
        bar.addView(btn("share", v -> share()));
        bar.addView(btn("more", v -> menu(v)));
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(MATCH, WRAP);
        bl.setMargins(Ui.dp(8), Ui.dp(6), Ui.dp(8), Ui.dp(4));
        col.addView(bar, bl);

        FrameLayout body = new FrameLayout(this);
        edit = new EditText(this);
        edit.setBackground(null);
        edit.setGravity(Gravity.TOP | Gravity.START);
        edit.setTextColor(t.text);
        edit.setHintTextColor(t.muted);
        edit.setHint("Start writing…");
        edit.setTextSize(16.5f);
        edit.setLineSpacing(0, 1.25f);
        edit.setPadding(Ui.dp(20), Ui.dp(10), Ui.dp(20), Ui.dp(24));
        edit.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES | android.text.InputType.TYPE_TEXT_FLAG_AUTO_CORRECT);
        edit.setHighlightColor(Palette.alpha(t.a1, 90));
        edit.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!busy && before == 0 && count == 1 && s.charAt(start) == '\n') newlineAt = start; else newlineAt = -1;
            }
            @Override public void afterTextChanged(Editable s) {
                if (busy) return;
                if (newlineAt >= 0) { int at = newlineAt; newlineAt = -1; continueList(s, at); }
                updateHeader();
                schedule();
            }
        });
        body.addView(edit, new FrameLayout.LayoutParams(MATCH, MATCH));
        read = new DocView(this);
        read.setVisibility(View.GONE);
        body.addView(read, new FrameLayout.LayoutParams(MATCH, MATCH));
        col.addView(body, new LinearLayout.LayoutParams(MATCH, 0, 1f));

        // formatting toolbar
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout tools = new LinearLayout(this);
        tools.setGravity(Gravity.CENTER_VERTICAL);
        tools.setPadding(Ui.dp(6), Ui.dp(4), Ui.dp(6), Ui.dp(4));
        tools.setBackground(Ui.panel(22));
        String[] names = {"H", "B", "I", "•", "☐", "1.", "❝", "</>", "—"};
        for (final String nm : names) {
            TextView tv = label(nm, 17, t.text, true);
            if (nm.equals("I")) tv.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD_ITALIC));
            tv.setGravity(Gravity.CENTER);
            tv.setMinWidth(Ui.dp(46));
            tv.setPadding(Ui.dp(8), Ui.dp(8), Ui.dp(8), Ui.dp(8));
            tv.setOnClickListener(v -> tool(nm));
            tools.addView(tv);
        }
        hs.addView(tools);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(WRAP, WRAP);
        tl.setMargins(Ui.dp(10), Ui.dp(2), Ui.dp(10), Ui.dp(8));
        tl.gravity = Gravity.CENTER_HORIZONTAL;
        col.addView(hs, tl);
        toolbar = hs;

        setContentView(root);
        getWindow().setStatusBarColor(t.bg1);
        getWindow().setNavigationBarColor(t.bg2);
        WindowInsetsController wc = getWindow().getInsetsController();
        if (wc != null) {
            int light = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
            wc.setSystemBarsAppearance(t.dark ? 0 : light, light);
        }
    }

    private View toolbar;

    private void updateHeader() {
        String text = edit.getText().toString();
        String t = Notes.titleOf(text);
        titleView.setText(t.isEmpty() ? "New note" : t);
        int words = text.trim().isEmpty() ? 0 : text.trim().split("\\s+").length;
        subView.setText(words + (words == 1 ? " word" : " words") + (dir != null && file != null ? "" : ""));
    }

    // ---- saving -------------------------------------------------------------------------------------
    private void schedule() {
        ui.removeCallbacks(saver);
        ui.postDelayed(saver, 800);
    }

    private void save() {
        if (!loaded) return;
        String text = edit.getText().toString();
        if (text.equals(lastSaved)) return;
        try {
            if (file == null) {
                if (text.trim().isEmpty()) return;
                file = Notes.newFile(dir, text);
            }
            Notes.write(file, text);
            lastSaved = text;
        } catch (IOException e) {
            toast("Couldn’t save: " + e.getMessage());
        }
    }

    /** On leaving: delete an empty note, otherwise name the file after its first line. */
    private void tidy() {
        save();
        if (file == null) return;
        String text = edit.getText().toString();
        if (text.trim().isEmpty()) {
            file.delete();
            return;
        }
        File nf = Notes.renameToTitle(file, text);
        if (!nf.equals(file)) {
            Set<String> pins = new HashSet<>(prefs.getStringSet("pins", new HashSet<String>()));
            if (pins.remove(file.getPath())) { pins.add(nf.getPath()); prefs.edit().putStringSet("pins", pins).apply(); }
            file = nf;
        }
    }

    // ---- markdown helpers ---------------------------------------------------------------------------
    private int lineStart(CharSequence s, int pos) {
        int i = Math.max(0, Math.min(pos, s.length()));
        while (i > 0 && s.charAt(i - 1) != '\n') i--;
        return i;
    }

    private int lineEnd(CharSequence s, int pos) {
        int i = Math.max(0, Math.min(pos, s.length()));
        while (i < s.length() && s.charAt(i) != '\n') i++;
        return i;
    }

    /** After Enter on a list line: carry the bullet / checkbox / number to the new line (or stop the list if it was empty). */
    private void continueList(Editable s, int nlPos) {
        int ls = lineStart(s, nlPos);
        String line = s.subSequence(ls, nlPos).toString();
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("^(\\s*)([-*+] \\[[ xX]\\] |[-*+] |(\\d+)[.)] )").matcher(line);
        if (!m.find()) return;
        String rest = line.substring(m.end());
        busy = true;
        try {
            if (rest.trim().isEmpty()) {
                s.delete(ls, nlPos + 1);          // empty item + Enter ends the list
                Selection.setSelection(s, ls);
            } else {
                String prefix = m.group(1) + m.group(2);
                if (m.group(3) != null) prefix = m.group(1) + (Integer.parseInt(m.group(3)) + 1) + m.group(2).substring(m.group(3).length());
                else if (prefix.contains("[")) prefix = m.group(1) + m.group(2).replaceAll("\\[[xX]\\]", "[ ]");
                s.insert(nlPos + 1, prefix);
                Selection.setSelection(s, nlPos + 1 + prefix.length());
            }
        } finally { busy = false; }
    }

    private void tool(String which) {
        if (reading) setReading(false);
        Editable s = edit.getText();
        int a = Math.min(edit.getSelectionStart(), edit.getSelectionEnd()), b = Math.max(edit.getSelectionStart(), edit.getSelectionEnd());
        if (a < 0) { a = b = s.length(); }
        switch (which) {
            case "B": wrap(s, a, b, "**"); break;
            case "I": wrap(s, a, b, "*"); break;
            case "</>": wrap(s, a, b, "`"); break;
            case "H": linePrefix(s, a, "heading"); break;
            case "•": linePrefix(s, a, "- "); break;
            case "☐": linePrefix(s, a, "check"); break;
            case "1.": linePrefix(s, a, "1. "); break;
            case "❝": linePrefix(s, a, "> "); break;
            default: s.insert(lineEnd(s, b), "\n\n---\n"); break;
        }
    }

    private void wrap(Editable s, int a, int b, String m) {
        if (a == b) {
            s.insert(a, m + m);
            Selection.setSelection(s, a + m.length());
        } else {
            boolean already = a >= m.length() && b + m.length() <= s.length()
                    && s.subSequence(a - m.length(), a).toString().equals(m) && s.subSequence(b, b + m.length()).toString().equals(m);
            if (already) { s.delete(b, b + m.length()); s.delete(a - m.length(), a); Selection.setSelection(s, a - m.length(), b - m.length()); }
            else { s.insert(b, m); s.insert(a, m); Selection.setSelection(s, a + m.length(), b + m.length()); }
        }
    }

    private void linePrefix(Editable s, int pos, String kind) {
        int ls = lineStart(s, pos), le = lineEnd(s, pos);
        String line = s.subSequence(ls, le).toString();
        String stripped = line.replaceFirst("^(#{1,6} |[-*+] \\[[ xX]\\] |[-*+] |\\d+[.)] |> )", "");
        String lead = line.substring(0, line.length() - stripped.length());
        String repl;
        switch (kind) {
            case "heading":
                if (lead.startsWith("### ")) repl = stripped;
                else if (lead.startsWith("## ")) repl = "### " + stripped;
                else if (lead.startsWith("# ")) repl = "## " + stripped;
                else repl = "# " + stripped;
                break;
            case "check":
                if (lead.matches("[-*+] \\[ \\] ")) repl = "- [x] " + stripped;
                else if (lead.matches("[-*+] \\[[xX]\\] ")) repl = "- [ ] " + stripped;
                else repl = "- [ ] " + stripped;
                break;
            default:
                repl = lead.equals(kind) ? stripped : kind + stripped;
        }
        s.replace(ls, le, repl);
        Selection.setSelection(s, ls + repl.length());
    }

    // ---- modes / menu -------------------------------------------------------------------------------
    private void setReading(boolean on) {
        reading = on;
        readBtn.setKind(on ? "edit" : "show");
        if (on) {
            save();
            Paper.set(Ui.t.dark);
            read.setBackgroundColor(0x00000000);
            read.setDoc(TextDoc.markdown(edit.getText().toString()), false);
            read.refreshColours();
            read.setBackgroundColor(0x00000000);
            read.setVisibility(View.VISIBLE);
            edit.setVisibility(View.GONE);
            toolbar.setVisibility(View.GONE);
            InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (im != null) im.hideSoftInputFromWindow(edit.getWindowToken(), 0);
        } else {
            read.setVisibility(View.GONE);
            edit.setVisibility(View.VISIBLE);
            toolbar.setVisibility(View.VISIBLE);
        }
    }

    private void share() {
        String text = edit.getText().toString();
        if (text.trim().isEmpty()) { toast("Nothing to share yet"); return; }
        Intent s = new Intent(Intent.ACTION_SEND);
        s.setType("text/plain");
        s.putExtra(Intent.EXTRA_SUBJECT, Notes.titleOf(text));
        s.putExtra(Intent.EXTRA_TEXT, text);
        startActivity(Intent.createChooser(s, "Share note"));
    }

    private void menu(View anchor) {
        PopupMenu m = new PopupMenu(this, anchor);
        boolean pinned = file != null && prefs.getStringSet("pins", new HashSet<String>()).contains(file.getPath());
        m.getMenu().add(0, 1, 0, pinned ? "Unpin" : "Pin to top");
        m.getMenu().add(0, 2, 1, "Details");
        m.setOnMenuItemClickListener(it -> {
            if (it.getItemId() == 1) {
                if (file == null) { save(); }
                if (file == null) { toast("Write something first"); return true; }
                Set<String> pins = new HashSet<>(prefs.getStringSet("pins", new HashSet<String>()));
                if (!pins.remove(file.getPath())) pins.add(file.getPath());
                prefs.edit().putStringSet("pins", pins).apply();
            } else details();
            return true;
        });
        m.show();
    }

    private void details() {
        String text = edit.getText().toString();
        int words = text.trim().isEmpty() ? 0 : text.trim().split("\\s+").length;
        StringBuilder sb = new StringBuilder();
        sb.append(words).append(" words, ").append(text.length()).append(" characters\n");
        if (file != null) {
            sb.append("Edited: ").append(DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(new Date(file.lastModified()))).append('\n');
            sb.append("File: ").append(file.getPath());
        } else sb.append("Not saved yet");
        new AlertDialog.Builder(this).setTitle("Details").setMessage(sb.toString()).setPositiveButton("Close", null).show();
    }
}
