# Mellow Notes
Soft, glassy notes for Android 11+. Every note is a plain .md file in Documents/MellowNotes (folders are real folders).
Needs "All files access". Shares trash with the other Mellow apps.
